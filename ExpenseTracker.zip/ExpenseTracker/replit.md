# Expense Tracker Application

## Overview

This is a full-stack expense tracking application built with React and Express.js. The application allows users to create, view, and manage their personal expenses with categorization and filtering capabilities. It features a modern, responsive design using shadcn/ui components and Tailwind CSS.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure
- **Validation**: Zod schemas for request/response validation
- **Development**: Hot reload with tsx for TypeScript execution

### Data Storage
- **Database**: PostgreSQL (configured for production)
- **ORM**: Drizzle ORM for type-safe database operations
- **Development Storage**: In-memory storage implementation for development
- **Migration**: Drizzle Kit for database schema management

## Key Components

### Shared Schema (`shared/schema.ts`)
- Centralized data models and validation schemas
- Expense entity with categories: food, transport, shopping, entertainment, utilities, healthcare, education, others
- Type-safe interfaces using Drizzle ORM and Zod validation

### Storage Layer (`server/storage.ts`)
- Abstract storage interface for database operations
- Memory-based implementation for development
- Support for CRUD operations and category-based filtering

### API Routes (`server/routes.ts`)
- RESTful endpoints for expense management:
  - `GET /api/expenses` - Retrieve all expenses or filter by category
  - `POST /api/expenses` - Create new expense with validation
  - `DELETE /api/expenses/:id` - Remove specific expense

### Frontend Pages
- **Expense Tracker**: Main application interface with expense list, creation form, and filtering
- **Not Found**: Error page for unmatched routes

### UI Components
- Comprehensive shadcn/ui component library
- Custom styled components with dark theme support
- Responsive design with mobile-first approach

## Data Flow

1. **User Input**: Forms capture expense data with real-time validation
2. **Client Validation**: Zod schemas validate data before API calls
3. **API Processing**: Express routes handle requests with server-side validation
4. **Data Storage**: Storage layer persists data (memory in dev, PostgreSQL in production)
5. **State Management**: React Query manages caching, synchronization, and optimistic updates
6. **UI Updates**: Components automatically re-render when data changes

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection for production
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling and validation
- **zod**: Schema validation
- **date-fns**: Date formatting and manipulation

### UI Dependencies
- **@radix-ui/***: Headless UI components
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and development server
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling for server code

## Deployment Strategy

### Development Environment
- Vite development server with hot module replacement
- In-memory storage for rapid development
- TypeScript compilation with tsx
- Auto-reload on file changes

### Production Build
- Vite builds optimized React application to `dist/public`
- esbuild bundles Express server to `dist/index.js`
- Static file serving from build output
- Environment-based configuration

### Database Strategy
- Development: In-memory storage implementation
- Production: PostgreSQL with Drizzle ORM
- Migration support through Drizzle Kit
- Environment variable configuration for database connections

### Configuration Management
- Environment variables for database URLs
- Conditional logic for development vs production
- Type-safe configuration validation
- Replit-specific optimizations for cloud deployment

The application is designed to be easily deployable on Replit with automatic database provisioning and environment configuration.